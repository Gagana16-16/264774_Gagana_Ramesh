 
#Session 3: [Individual] [20]

#  Given an IP address string "192-168-1-1" correct it 
str="192-168-1-1"
print(str.replace("-",":"))

#  Convert "hello world" to uppercase
str1="hello world"
print(str1.upper())

#  Swap the case of "PyThOn StRiNgS"
str2="PythOn StRiNgS"
print(str2.swapcase())

#  Find the length of "Hello, Python!"
str16="Hello, Python!"
print(len(str16))

#  Count how many times "e" appears in "experience"
str3="experience"
print(str3.count("e"))


#  Check if "Python programming" starts with "Py"
str4="Python programming"
print(str4.startswith('Py'))


#  Check if "hello.txt" ends with ".txt"
str5="hello.txt"
print(str5.endswith('txt'))


#  Find the index of "world" in "hello world"
str6="hello world"
print(str6.index("world"))


#  Replace "Python" with "Java" in "I love Python"
str7="I Love Python"
print(str7.replace('Python','Java'))


#  Remove leading and trailing spaces from " Python "
str8=" Python "
print(str8.strip())


#  Split "Learn Python Programming" into words
str9="Learn python programming"
print(str9.split())


#  Join ['apple', 'banana', 'cherry'] with commas
str10=['apple','banana','cherry']
print(",".join(str10))

#  Check if "Python3" is alphanumeric
str11='Python3'
print(str11.isalnum())

#  Convert "5" to a 3-digit string ("005")
str12="5"
print(str12.zfill(5))

#  Given name = "Alice" and age = 25, format "Alice is 25 years old."
name="Alice" 
age=25

print("{0:5} is {1:2} years old".format(name,age))


#  Check if 'malayalam' is a palindrome
str13="malayalam"
if(str13==str13[::-1]):
    print("palindrom")
else:
    print("not palindrom")



#  Session 4:

#  Create a program to accept text from the user and count the number of vowels
#  in the text

text="gafe yHTF swfyw  GGJWeee"
texts=text.lower()
vcount=0
for i in 'aieou':
    vcount+= text.count(i)
print(vcount)