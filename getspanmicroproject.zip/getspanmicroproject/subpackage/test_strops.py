'''Microsoft Windows [Version 10.0.26100.3476]
(c) Microsoft Corporation. All rights reserved.

C:\Users\264774\Desktop\python_train>cd C:\Users\264774\Desktop\python_train\myenv\Scripts

C:\Users\264774\Desktop\python_train\myenv\Scripts>activate

(myenv) C:\Users\264774\Desktop\python_train\myenv\Scripts>cd C:\Users\264774\Desktop\python_train\getspanmicroproject

(myenv) C:\Users\264774\Desktop\python_train\getspanmicroproject>pip install .
Processing c:\users\264774\desktop\python_train\getspanmicroproject
  Installing build dependencies ... done
  Getting requirements to build wheel ... done
  Preparing metadata (pyproject.toml) ... done
Building wheels for collected packages: subpackage
  Building wheel for subpackage (pyproject.toml) ... done
  Created wheel for subpackage: filename=subpackage-0.1-py3-none-any.whl size=2508 sha256=a47a710041ff8d7ac47db319e28e253552f46cdee35d22219660124324144010
  Stored in directory: C:\Users\264774\AppData\Local\Temp\pip-ephem-wheel-cache-267oyds0\wheels\47\ac\3f\98cbee625b966ff9b78a4643f88af77dacb0328881d61f172f
Successfully built subpackage
Installing collected packages: subpackage
  Attempting uninstall: subpackage
    Found existing installation: subpackage 0.1
    Uninstalling subpackage-0.1:
      Successfully uninstalled subpackage-0.1
Successfully installed subpackage-0.1

[notice] A new release of pip is available: 24.3.1 -> 25.0.1
[notice] To update, run: python.exe -m pip install --upgrade pip

(myenv) C:\Users\264774\Desktop\python_train\getspanmicroproject>python
Python 3.13.2 (tags/v3.13.2:4f8bb39, Feb  4 2025, 15:23:48) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>> import subpackage
#1 getspan() function'''

----------------------------------------------------------------------------------------------------
'''enter the string-->mississipi
enter the substring-->ss'''
[2, [(2, 4), (5, 7)]]
----------------------------------------------------------------------------------------------------
#2 reverseWords(s) function

----------------------------------------------------------------------------------------------------
'''enter the string-->ReVerse Word
droW esreVeR'''
----------------------------------------------------------------------------------------------------
#3 remove puntuation function()

----------------------------------------------------------------------------------------------------
'''enter the sting-->The punctauation's 'should not be there'?
The punctauations should not be there'''
----------------------------------------------------------------------------------------------------
#4 countWords function()

----------------------------------------------------------------------------------------------------
'''enter the sentence-->the counting of the words'''
5
----------------------------------------------------------------------------------------------------
#5 charecterMap() function

----------------------------------------------------------------------------------------------------
'''enter the string-->missipppss'''
{'m': 1, 'i': 2, 's': 4, 'p': 3}
----------------------------------------------------------------------------------------------------
#6 makeTitle() function

----------------------------------------------------------------------------------------------------
'''enter the string for the title-->python training
Python Training'''
----------------------------------------------------------------------------------------------------
#7 normalizeSpaces() function

----------------------------------------------------------------------------------------------------
'''enter the string normalize spaces------>the   space   extra should  not be there
the space extra should not be there'''
----------------------------------------------------------------------------------------------------
#8 transform() function

----------------------------------------------------------------------------------------------------
'''enter the string to translate-->TransfORm
MroFSNARt'''
----------------------------------------------------------------------------------------------------
#9 permuntations function()

----------------------------------------------------------------------------------------------------
'''enter string---->abcd
24 ways'''
['cbda', 'badc', 'cadb', 'bacd', 'bcad', 'dbca', 'cdab', 'acdb', 'acbd', 'bdac', 'dabc', 'dcab', 'dcba', 'dacb', 'adbc', 'bdca', 'abdc', 'cbad', 'bcda', 'abcd', 'cdba', 'cabd', 'dbac', 'adcb']
----------------------------------------------------------------------------------------------------
