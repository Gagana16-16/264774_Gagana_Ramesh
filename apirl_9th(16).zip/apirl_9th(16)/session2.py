Session 2: [60]
-------------------------------------------------------------------------------------------

Problem Statement: 1
--------------------------------------

You are tasked with developing a simple student record management system using SQLite3 in Python. The system should perform the following operations:

Requirements:

Create a SQLite database named school.db with a table students having fields:

    id (INTEGER, Primary Key, Auto-increment)
    name (TEXT)
    age (INTEGER)
    grade (TEXT)

- Insert at least three student records into the table using parameterized queries.
- Fetch and print all student records.
- Update the grade of a specific student based on their name.
- Delete a student record based on the id.
- Display the remaining students and the total number of students.
- Finalize and close the connection

Deliverables:

- Python code with all the required database operations.
- Clear output showing the operations performed.
- Use of best practices: parameterized queries, commit(), and close().
