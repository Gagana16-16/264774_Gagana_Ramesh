'''take 3 input coordinates from user
calculate the distance between the coordinate 
check whether it is isosceles and right angled triangle'''

import math

# Function to calculate distance between two points (x1, y1) and (x2, y2)
def calculate_distance(x1, y1, x2, y2):
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

# Function to check if the triangle is isosceles
def is_isosceles(d1, d2, d3):
    return d1 == d2 or d2 == d3 or d1 == d3

# Function to check if the triangle is right-angled using the Pythagorean theorem
def is_right_angle(d1, d2, d3):
    sides = sorted([d1, d2, d3])  # Sort distances to get the hypotenuse as the largest side
    return math.isclose(sides[0]**2 + sides[1]**2, sides[2]**2)

# Input coordinates for the three points
x1, y1 = map(float, input("Enter the first coordinate (x1, y1): ").split())
x2, y2 = map(float, input("Enter the second coordinate (x2, y2): ").split())
x3, y3 = map(float, input("Enter the third coordinate (x3, y3): ").split())

# Calculate the distances between the points
d1 = calculate_distance(x1, y1, x2, y2)
d2 = calculate_distance(x2, y2, x3, y3)
d3 = calculate_distance(x1, y1, x3, y3)

# Display the distances
print(f"Distance between point 1 and point 2: {d1}")
print(f"Distance between point 2 and point 3: {d2}")
print(f"Distance between point 1 and point 3: {d3}")

# Check if the triangle is isosceles
if is_isosceles(d1, d2, d3):
    print("The triangle is isosceles.")
else:
    print("The triangle is not isosceles.")

# Check if the triangle is right-angled
if is_right_angle(d1, d2, d3):
    print("The triangle is right-angled.")
else:
    print("The triangle is not right-angled.")

