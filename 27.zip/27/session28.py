


def charecterMap(s):
    d={}
    count=0
    for i in s:
        if(i in d):
            d[i]+=1
        else:
            d[i]=count+1

    print(d)
print('-'*20)
str=input("enter the string")
charecterMap(str)
print('-'*20)
# def normalize(str):
#     str1="" 
#     character=''
#     for i in str:
        
#         if(character!=" "):
#             str1=str1+i
#         else:
#             pass
#         character=i
#     print(str1)
# print("-"*100)
# str=input("enter the string normalize spaces------>")
# normalize((str).strip())

# print("-"*100)







# import random

# def factorial(num):
#     fact=1
#     if(num<0):
#         raise ("value not found")
#     while(num!=0):   
#         fact=fact*num
#         num=num-1
#     return(fact)

# def permuntations(data):
#     mn=factorial(len(list(data)))
#     print(mn,'ways')
#     list1=[]
#     a=list(data)
#     random.shuffle(a)
#     na=''.join(a)
#     for i in range(mn):
#         random.shuffle(a)
#         na=''.join(a)
#         while True:
#             if na not in list1:
#                 list1.append(''.join(a))
#                 break
#             else:
#                 random.shuffle(a)
#                 na=''.join(a)

#     return(list1)

# data=input("enter string")
# print(permuntations(data))






# def jumbled(example):
#     list1=[]
#     list2=[]
#     str=""

#     for i in range(len(example)):
#         print(i)
#         for j in range(len(example)):
#             print(j)
#             a=random.randint(0, len(example)-1)
#             while a in list1:
#                 a=random.randint(0, len(example)-1)  
#             else:
#                 list1.append(a)
#                 print(j)
        
#             str=str+example[a]+" "
#             print(j)
#         print(str)
#         list2.append(str)
#     print(list2)
# jumbled('example')








 
# # def jumbled(example):
# #     list1=[]
# #     list2=[]
# #     str=""
# #     for i in range(len(example)):
# #         for i in range(len(example)):
# #             a=random.randint(0, len(example)-1)
# #             while a in list1:
# #                 a=random.randint(0, len(example)-1)  
# #             else:
# #                 list1.append(a)
        
# #             str=str+example[a]+" "
# #         print(str)
# #         list2.append(str)
# #         print(str)
# # jumbled('example')



