str1 = "mississippis"

ss = 'ss'
count=0
[(2,4),(5,7)]

list1=[]
start=0
end=0
start1=0
while(start1!=-1):
    start1=str1[start:].find(ss)
    if(start1==-1):
        break
    print(start1)
    print(str1[start:])
    start=str1[start:].find(ss)+start
    print(start)
    end=start+len(ss)
    print(end)
    list1.append((start,end))
    print(list1)
    count+=1
    start=end+1
print(list1)

# start=0
# end=0
# while(end!=len(str1)-1):
#     start=str1[start:].find(ss)+start
#     print(str1[start:])
#     end=start+len(ss)
#     list1.append((start,end))
#     count+=1
#     start=end+1
# list1.append(count)
# print(list1)



