#3. Upgrade the getSpan(s, ss) function to raise an exception if ss = '' or s = '', test it

def spansub(s,n):
    assert s!="" and n!='' ,'string should be not empty'
    strt = 0
    p = []
    while strt < len(s):
        strt = s.find(n, strt) #return 2
        if strt == -1:
            break
        ed = strt + len(n) #4
        p.append((strt, ed))
        strt = ed  
    print([len(p),p])

 
 
if __name__ == "__main__":
    m_str = input("enter the string : ")
    sub_str = input("enter the sub_string : ")
    spansub(m_str, sub_str)