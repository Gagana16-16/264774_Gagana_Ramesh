#1. Write a functions that returns the jumbled version of the words with spaces and capital letters

   #Example: Input <- jumble("apples")

import random

def jumbled(example):
    list1=[]
    str=""
    
    for i in range(len(example)+1):
        a=random.randint(0, len(example))
        
        while a not in list1:
            list1.append(a)
        else:
            a=random.randint(0, len(example))
        print(list1)
        '''str=str+example[a]+" "
        list1.append(a)
        print(list1)'''

    return str

print(jumbled('example'))

#2. Write a function to determine if a number is a fibonacci number
   #Example: Input <- 8
            #OUtput -> 8 is in the fibonacci range

def fibonacci(num):
    list=[]
    a=0
    b=1
    list.append(a)
    list.append(b)
    for i in range(0,100):
        
        c=a+b  
        list.append(c) 
        a=b 
        b=c   
          
        
        print(list)   
    if num in list:
        print("fibonacii",num) 
    else:
        print("not fibonacii",num) 

fibonacci(7)


#3. Write a python function to merge two dictionaries
   #Example: d1 = { 'a': 20, 'b': 30 }
           # d2 = { 'b': 40, 'c': 50 }
            #Output -> { 'a' : 20, 'b':70, 'c' : 50 }
    #Merge rules: Numbers -> add
                # Strings -> concatenate
                 #List, set -> Merge
                # Tuple -> List of tuples
                # Dictionary -> Merge

d1 = { 'a': 20, 'b': 30 }
d2 = { 'b': 40, 'c': 50 }
d3={}
print(list(d1))
print(list(d2))


a=str(d1['b'])+str(d2['b'])
print(a)
for i in list(d1):
    if i in list(d2):
        if(type(d1[i])==type(d2[i])):
            d3[i]=d1[i]+d2[i]
            print(d3)
        else:
          d3[i]=str(d1[i])+str(d2[i]) 
    else:
        d3[i]=d1[i]
for i in list(d2):
    d3[i]=d2[i]
    print(d3)
