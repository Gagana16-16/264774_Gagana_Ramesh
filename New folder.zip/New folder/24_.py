#1. Write a function to return the time required to double the invested amount and given rate of interest
def interest(principle,rate_of_interest):
    time=1
    s=(principle*rate_of_interest*time)/100
    print(s)
    time=0

    time=(s*100)/((2*principle)*rate_of_interest)
    return time
print(interest(100000,6.5))

#. Write a function to find the second largest number in the list
   # Example: Input <- [34, 56, 67, 43]
            # Outupt -> 56

def largest(list):
    list=[10,20,30]
    a=max(list)
    list.remove(a)
    return max(list)


list=[10,20,30]
print(largest(list))

#3. Write a function to print charecter pyramid
    #Example: genPyramic(3, '*')
                #  *
                # ***
                #*****

def genPyramic(n,star):
    for i in range(n):
        for j in range(n+2):
            if(i+j!=1):
                print(" ",end=" ")
            else:
                print(star,end=" ")
        print()
genPyramic(3,'*')


def swap(a,b):
    temp=a
    a=b
    b=temp
    print(a,b)
swap(10,20)