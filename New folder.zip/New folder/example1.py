import random

def jumbled(example):
    list1=[]
    str=""
    
    for i in range(len(example)):
        a=random.randint(0, len(example)-1)
        while a in list1:
            a=random.randint(0, len(example)-1)   
        else:
            list1.append(a)
        str=str+example[a]+""
    #print(list1)
    print(str) 
jumbled('example')