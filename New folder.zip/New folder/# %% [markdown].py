# %% [markdown]
# ### 9.1 itemgetter()

# %%
from operator import itemgetter

# %%
itemgetter(1)('apples')

# %%
itemgetter(1)(["red", "green", "blue"])

# %%
L.sort(key=itemgetter(1))

# %%
L

# %%
f = itemgetter(1)

# %%
f

# %%
f("apples")

# %% [markdown]
# ### 9.2 datetime Module

# %%
from datetime import datetime

# %%
# Getting the current date and time
t = datetime.now()
t

# %%
print(t.year, t.month, t.day, t.hour, t.minute, t.second)

# %%
# "Thursday, 20 May 2020, 9:53 AM"
f = "%A, %d %B %Y, %I:%M %p"
print(t.strftime(f))

# %%
t1 = datetime.now()

# %%
t1 - t

# %% [markdown]
# ### 9.3 itertools Module

# %%
from itertools import permutations, combinations

# %%
s = "ABCD"

# %%
p = permutations(s)
list(p)

# %%
c = combinations(s, 4)
list(c)

# %%
list(combinations(s, 3))

# %% [markdown]
# ### 9.4 collections Module

# %%
s = "mississippi"
L = list(s)
L

# %%
CH = {}
for c in L:
    if(c in CH.keys()):
        CH[c] = CH[c] + 1
    else:
        CH[c] = 1
CH

# %%
from collections import Counter
t = Counter(L)
t

# %% [markdown]
# ### 9.5 Working with Filesystems

# %%
import os
import os.path
import shutil

# %%
path = r"./mydir"

# %%
os.getcwd()

# %%
os.chdir(path)

# %%
os.getcwd()

# %%
os.listdir()

# %%
f = 'data1.txt'
os.path.splitext(f)

# %%
os.path.splitext(f)[1][1:]

# %%
# Extract all the extensions
exts = []
for file in os.listdir():
    ext = os.path.splitext(file)[1][1:]
    exts.append(ext)
exts

# %%
# Remove all duplicates
exts = set(exts)
exts

# %%
# create directories for each of the unique extensions
for ext in exts:
    os.mkdir(ext)

# %%
for item in os.listdir():
    if os.path.isfile(item):
        src = item
        dest = os.path.splitext(item)[1][1:] #ext
        finaldest = os.path.join(dest, item) #xlsx/data.xlsx
        shutil.move(src, finaldest)

# %%
finaldest

# %% [markdown]
# ### 9.6 Executing System Commands

# %%
import subprocess

# %%
subprocess.call("dir", shell=True)

# %%
content = subprocess.check_output("dir", shell=True)

# %%
print(content)

# %%
type(content)

# %%
content = content.decode()

# %%
print(content)

# %%
type(content)

# %% [markdown]
# ### 9.7 Comprehensions

# %%
N = list(range(20))
N

# %%
D3 = []
for n in N:
    if(n % 3 == 0):
        D3.append(n)
D3

# %%
[n for n in N if n % 3 == 0]

# %% [markdown]
# ### [<expr> <loop> <condition>] () {}

# %%
list(n for n in range(20) if n % 2 == 0)

# %%
[n**2 for n in N if n in [2, 9, 13]]

# %%
[(n, n**2, n**3) for n in [2, 5, 7, 9]]

# %%
L = ["red", "green", "blue", "yellow"]

# %%
{s:len(s) for s in L}

# %%
N = [1, 2, 3, 4, 5, 6]

# %%
[x**2 for x in N if x in [2, 5]]

# %%
[x**2 if x in [2, 5] else x for x in N]

# %%
[x**2 if x % 2 == 0 else x for x in N]

# %%
[(x, y) for x in range(10) for y in range(10) if x + y == 11]

# %%
d = {'red': 3, 'green': 5, 'blue': 4, 'yellow': 6}

# %%
{v:k for k,v in d.items()}

# %%



