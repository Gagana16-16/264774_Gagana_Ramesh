# Session 3:
# ---------------------------------------------------------------------------------------------------------
# 1. Design a Word Jumble Game and implement in python
#    The game should consist of atleast 10 words to begin with
#     Jumbled Word: "otpcomure"
#     Your Guess: "computer"
#     ✅ Correct! 

#     Note: Use Unicode charecter to print the tick marks
#     Example: print("\U00002705 Correct!")


str='mississippi'
input1='ss'
a=[]
#output (2,[(2,4),(5,7)])
# count=0
# start=str.find(input1)
# end=start+len(input1)
# print(start,end)
# print(str[start:end])
# print(str[end:])
# count+=1
# a.append((start,end))

# start=str[end:].find(input1)
# end1=start+len(input1)
# print(end1)
# print(start+end,end+end)
# print(str[start+end:end1+end])
# a.append((start,end))
# count+=1

# start=str[end1:].find(input1)
# print(str[end1:])
# end1=start+len(input1)
# print(start+end,end+end)
# print(str[start+end:end1+end])
# a.append((start,end))
# count+=1

# print(count,a)
# print(str[end1:])


str='mississippi'
input1='ss'
a=[]    
start=0
end=len(str)
start=str[start:end].find(input1)


# while(start!=-1):
#     count=0
#     start=str[start:end].find(input1)
#     end=start+len(input1)
#     print(start,end)
#     print(str[start:end])
#     print(str[end:])
#     count+=1
#     list1.append((start,end))
# print(list)