class Person:
    def __init__(self,name,age,gender):
        self.name=name
        self.age=age
        self.gender=gender

    def get_details(self):
        return f"{self.name}','{str(self.age)}','{str(self.gender)}"
    
class Employee(Person):
    number=0
    data_string=[]
    def __init__(self,name,age,gender,emp_id,deparment,salary):
        self.emp_id=emp_id
        self.deparment=deparment
        self.salary=salary
        super().__init__(name,age,gender)
    def get_details(self):
        Employee.data_string.append(f"{super().get_details()}','{str(self.emp_id)}','{str(self.deparment)}','{str(self.salary)}'")
        return f"{super().get_details()}','{str(self.emp_id)}','{str(self.deparment)}','{str(self.salary)}'"
        
    def is_eligible_for_bonus(self):
        if(self.salary<50000):
            return True
        else:
            return False
        
    @classmethod
    def from_string(cls,data=0):
        p=[]
        for i in Employee.data_string:
            result = i.replace("'", "")
            p.append(result)
        return p

    @staticmethod
    def bonus_policy():
        print("----------------Decription-----------------")
        print("the employee is eligble only which is less than 500000")
        print("the employee is not eligble")
        

E=Employee('gagana',21,'F',1212,'finance',120000)
print(E.get_details())
# Employee.from_string()
print(E.bonus_policy())
print(Employee.data_string)

E=Employee('ganga',21,'F',1213,'HR',120000)
print(E.get_details())
print(E.bonus_policy())
print(Employee.data_string)   
Employee.from_string('datasting')


class Department():
    def __init__(self,name,p=0):
        self.name=name
        self.p=len(Employee.from_string('datasting'))
    def add_employee(self,name,age,gender,emp_id,deparment,salary):
        self.p=self.p+1 

    def get_average_salary(self):
        b=0
        for i in range(self.p):
            a=list(Employee.from_string('datasting')[i])
            b=a
            print(b)
            #str(reversed(Employee.from_string('datasting')[i][-1:-7:-1]))
            # a=int(Employee.from_string('datasting')[i][5])+a/self.p

D=Department('gagana')
#D.add_employee('gaga')
D.get_average_salary()