# INFO -> step 3 -> Class dictionary after averages updated
rank=0
clsdict={'HPE001': {'name': 'Vijay', 'age': '14', 'regid': 'HPE001', 'phy': '99', 'chem': '98', 'math': '97', 'bio': '96', 'avg': '0', 'rank': '0'}, 'HPE002': {'name': 'Aryan', 'age': '14', 'regid': 'HPE002', 'phy': '98', 'chem': '91', 'math': '93', 'bio': '96', 'avg': '0', 'rank': '0'}, 'HPE003': {'name': 'Muni', 'age': '14', 'regid': 'HPE003', 'phy': '97', 'chem': '98', 'math': '97', 'bio': '94', 'avg': '0', 'rank': '0'}, 'HPE004': {'name': 'Abhi', 'age': '14', 'regid': 'HPE004', 'phy': '96', 'chem': '93', 'math': '97', 'bio': '95', 'avg': '0', 'rank': '0'}, 'HPE005': {'name': 'Hemanth', 'age': '14', 'regid': 'HPE005', 'phy': '94', 'chem': '91', 'math': '93', 'bio': '96', 'avg': '0', 'rank': '0'}, 'HPE006': {'name': 'Grace', 'age': '14', 'regid': 'HPE006', 'phy': '94', 'chem': '95', 'math': '96', 'bio': '97', 'avg': '0', 'rank': '0'}, 'CAP007': {'name': 'Ankita', 'age': '14', 'regid': 'CAP007', 'phy': '99', 'chem': '99', 'math': '99', 'bio': '99', 'avg': '0', 'rank': '0'}, 'HPE008': {'name': 'John', 'age': '14', 'regid': 'HPE008', 'phy': '96', 'chem': '93', 'math': '97', 'bio': '95', 'avg': '0', 'rank': '0'}, 'HPE009': {'name': 'Chris', 'age': '14', 'regid': 'HPE009', 'phy': '94', 'chem': '91', 'math': '93', 'bio': '96', 'avg': '0', 'rank': '0'}, 'ORA006': {'name': 'Grace', 'age': '14', 'regid': 'ORA006', 'phy': '94', 'chem': '95', 'math': '96', 'bio': '97', 'avg': '0', 'rank': '0'}, 'INF007': {'name': 'Ankita', 'age': '14', 'regid': 'INF007', 'phy': '99', 'chem': '99', 'math': '99', 'bio': '99', 'avg': '0', 'rank': '0'}}



for i in clsdict.keys():

    clsdict[i]['avg']=(int(clsdict[i]['phy'])+int(clsdict[i]['chem'])+int(clsdict[i]['math'])+int(clsdict[i]['bio']))/4




# INFO -> step 4 -> Class dictionary after rank updated


list1=[]
for i in clsdict.keys():
    list1.append(clsdict[i]['avg'])
print(list1)

def abc(c=0):
    global rank
    for i, j in clsdict.items():
        if(j['avg'] == c and j['rank']=='0'):
            rank=rank+1
            j['rank']=rank
            break

for i in clsdict.keys():
       a=max(list1)
       abc(a)
       list1.remove(a)


for i in clsdict:
     print(clsdict[i])


file2=open('student_report.csv','w')
template = "{0:8} | {1:15} | {2:5} | {3:5} | {4:5} | {5:5} | {6:5} | {7:5} | {8:5}"
line = '-'*90

file2.write("\nCLASS REPORT\n")
for regid in clsdict.keys():
    name = clsdict[regid]['name']
    id = clsdict[regid]['regid']
    age = clsdict[regid]['age']
    phy = clsdict[regid]['phy']
    chem = clsdict[regid]['chem']
    math = clsdict[regid]['math']
    bio = clsdict[regid]['bio']
    avg = clsdict[regid]['avg']
    rank = clsdict[regid]['rank']
    a=[id,name,age,phy,chem,math,bio,str(avg),str(rank)]
    b=','.join(a)
    file2.write(b)
    file2.write('\n')

file2.close()
file2=open('student.txt','w')

template = "{0:8} | {1:15} | {2:5} | {3:5} | {4:5} | {5:5} | {6:5} | {7:5} | {8:5}"
line = '-'*90

file2.write(template.format('REGID', 'NAME', 'AGE', 'PHY', 'CHEM', 'MATH', 'BIO', 'AVG', 'RANK')+'\n')
for regid in clsdict.keys():
    name = clsdict[regid]['name']
    id = clsdict[regid]['regid']
    age = clsdict[regid]['age']
    phy = clsdict[regid]['phy']
    chem = clsdict[regid]['chem']
    math = clsdict[regid]['math']
    bio = clsdict[regid]['bio']
    avg = clsdict[regid]['avg']
    rank = clsdict[regid]['rank']
    file2.write(template.format(id, name, age, phy, chem, math, bio, avg, rank)+'\n')
file2.write(line)
file2.close()