from setuptools import setup

setup(
    name='subpackage',
    version='0.1',
    description='microproject',
    url='#',
    author='Gagana',
    author_email='gagana_264774@gmail.com',
    license='MIT',
    packages=['subpackage'],
    zip_safe=False)