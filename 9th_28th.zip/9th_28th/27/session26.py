def factorial(num):
    fact=1
    if(num<0):
        raise ("value not found")
    while(num!=0):   
        fact=fact*num
        num=num-1
    print(fact)

a=int(input("enter the number"))
factorial(a)