# import random
# def jumbled(file1):
#     random.shuffle(file1)
#     print(file1)




# file1= open(r'C:\Users\264774\Desktop\python_train\27\simple1.txt','r')
# content=file1.readline()
# print(content)
# file1=content.split(',')
# print(file1)
# file1.close()
# copyfile=file1.copy()


file2= open(r'C:\Users\264774\Desktop\python_train\27\simple1.txt','r')
content1=file2.readlines()
list5=[]
for i in range(1,len(content1)):
    mn=content1[i].split(':')
    list5.append(mn)





# list1=[]
# for i in "apple":
#     for j in i:
#         list1.append(j)
#         random.shuffle(list1)
#         a="".join(list1)
# print(a)
# print(list1)

# list2=[]
# list3=[]

# for i in file1:
#     for j in i:
#         list2.append(j)
#         random.shuffle(list2)
#         a="".join(list2)
#     list2=[]    
#     list3.append(a)
# print(a)
# print(list3)

# random.shuffle(list3)
# print(list3)




# print("-"*100)
# print("welcome")
# print("-"*100)
# print()
# print()

# total=0
# for i in list3:
#     attempt=0
#     print("-"*20)
#     print(i)
#     input2=""
#     input1=""
#     input1=input("enter any crt value:")
    
#     if(input1 in file1 and attempt==0):
#         print('you got 2 points \U00002705')
#         points=2
#         attempt=1
#         total=total+points
#         print('-'*80)
#     else:
#         input2=input("enter any another value:")    
#         attempt=2
#         print('-'*80)

#     if(attempt==1 and input2 in file1):
#         print('you got 1 points')
#         points=1
#         attempt=2
#         total=total+points
#         print('-'*80)
#     if(attempt==2):
#         print('out of attempts\u274c')
# print('-'*80)
# print(total)


# if(total==6):
#     print("well played",'A grade \U00002728')
# elif(total>3 and total<6):
#     print("OK played",'B grade')
# else:
#     print("play next time well") 



# for i in range(len(list5)):
#     for j in range(2):
#         if (a==list5[i][j]):
#             print(list5[i][j])
#         else:
#             print("false")






