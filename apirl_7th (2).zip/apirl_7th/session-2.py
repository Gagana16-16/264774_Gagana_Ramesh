# Session 2 [60]
# Problem Statement #1:
# Create a Python class called Circle that represents a circle. The class should allow the following:
# Use @property to return the circumference of the circle using the formula 2 * π * radius.
# Use @classmethod to create a Circle instance from a diameter.
# Use @staticmethod to check if a given value is a valid radius (i.e., a positive number).

import math
class Circle:
    def __init__(self,radius):
        self.radius=radius
    @property
    def circum(self):
        return float(2 * (3.1416 *self.radius))
    @classmethod
    def diameter(cls,diameter):
        radius=diameter/2
        return cls(radius).circum
    @staticmethod
    def valid_radius(radius1):
        if(radius1>0):
            print('it is valid radius')
        else:
            print('it is not valid radius')


c=Circle(4)
print(c.circum)
print(Circle.diameter(7))
Circle.valid_radius(-1)




