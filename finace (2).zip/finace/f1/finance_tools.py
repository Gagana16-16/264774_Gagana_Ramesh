# Suggested Function Naming
# Function Name
# calculate_emi()
# calculate_sip()
# calculate_fd()
# calculate_rd()
# estimate_retirement_corpus()
# Purpose
# EMI for a loan
# SIP maturity amount
# FD maturity amount
# RD maturity amount
# Future retirement savings
# estimate_home_loan_eligibility() Max loan eligibility
# calculate_credit_card_balance() Credit card interest buildup
# calculate_taxable_income()
# plan_budget()
# calculate_net_worth()
# Post-deduction taxable income
# Budget recommendation
# Net worth computation
#
# EMI Formula:
# 𝐸
# 𝑀
# 𝐼
# =
# 𝑃
# ×
# 𝑅
# ×
# (
# 1
# +
# 𝑅
# )
# 𝑁
# (
# 1
# +
# 𝑅
# )
# 𝑁
# −
# 1
# EMI=
# (1+R)
# N
#  −1
# P×R×(1+R)
# N
#
# ​
#
# Where:
#
# EMI = Monthly payment
#
# P = Loan amount (Principal)
#
# R = Monthly interest rate = Annual interest rate / 12 / 100
#
# N = Loan tenure in months
#
# 📌 Want to try it?
# Please provide the following:
#
# Loan amount (P): e.g., ₹500,000
#
# Annual interest rate (%): e.g., 10%
#
# Loan tenure (in months or years): e.g., 5 years

#  --------------------------------------------------1 --------------------------------
def calculate_emi(principal, rate, tenure):
    if principal <= 0:
        raise ValueError("Principal must be positive.")
    if rate <= 0:
        raise ValueError("Interest rate must be positive.")
    if tenure <= 0:
        raise ValueError("Tenure must be positive.")

    monthly_rate = rate / (12 * 100)
    tenure_months = tenure * 12

    emi = (principal * monthly_rate * (1 + monthly_rate) ** tenure_months) / \
          ((1 + monthly_rate) ** tenure_months - 1)

    return round(emi, 2)

# loan_amount = float(input("Enter loan amount: "))
# interest_rate = float(input("Enter annual interest rate (%): "))
# loan_tenure = int(input("Enter loan tenure (in years): "))
# emi = calculate_emi(loan_amount, interest_rate, loan_tenure)
# print(f"Your monthly EMI is: ₹{emi}")


#  --------------------------------------------------2 --------------------------------
def calculate_sip(monthly_investment, annual_rate, years):
    r = annual_rate / (12 * 100)
    n = years * 12
    fv = monthly_investment * (((1 + r) ** n - 1) / r) * (1 + r)
    return round(fv, 2)
# sip_amount = float(input("Enter monthly SIP amount: "))
# interest_rate = float(input("Enter expected annual return rate (%): "))
# investment_duration = int(input("Enter investment duration (in years): "))
# future_value = calculate_sip(sip_amount, interest_rate, investment_duration)
# print(f"Future value of your SIP investment: ₹{future_value}")
#
# #  --------------------------------------------------3 --------------------------------
def calculate_fd(principal, annual_rate, years, compounding_frequency=4):
    r = annual_rate / 100
    n = compounding_frequency
    t = years
    maturity_amount = principal * (1 + r / n) ** (n * t)
    interest_earned = maturity_amount - principal
    return round(maturity_amount, 2), round(interest_earned, 2)
# principal = float(input("Enter principal amount (₹): "))
# interest_rate = float(input("Enter annual interest rate (%): "))
# tenure = float(input("Enter tenure (in years): "))
# frequency = int(input("Enter compounding frequency (1=yearly, 2=half-yearly, 4=quarterly, 12=monthly): "))
# maturity, interest = calculate_fd(principal, interest_rate, tenure, frequency)
# print(f"Maturity Amount: ₹{maturity}")
# print(f"Interest Earned: ₹{interest}")
#
# #  --------------------------------------------------4 --------------------------------
def calculate_rd(monthly_deposit, annual_rate, years):
    n = years * 12  # total months
    r = annual_rate / 400  # quarterly interest rate in decimal
    maturity_value = monthly_deposit * (((1 + r) ** n - 1) / (1 - (1 + r) ** -1))
    return round(maturity_value, 2)
# monthly_deposit = float(input("Enter monthly deposit amount (₹): "))
# interest_rate = float(input("Enter annual interest rate (%): "))
# tenure_months = int(input("Enter tenure (in months): "))
# maturity_amount, total_interest = calculate_rd(monthly_deposit, interest_rate, tenure_months)
# print(f"Maturity Amount: ₹{maturity_amount}")
# print(f"Interest Earned: ₹{total_interest}")
#
# #  --------------------------------------------------5--------------------------------
def estimate_retirement(current_savings, monthly_contribution, annual_return, years):
    r = annual_return / 12 / 100  # Monthly interest rate
    n = years * 12  # Total months

    # Future value of monthly contributions (SIP)
    fv_sip = monthly_contribution * (((1 + r) ** n - 1) / r) * (1 + r)
    # Future value of lump sum (current savings)
    fv_lump = current_savings * ((1 + r) ** n)

    # Total corpus (sum of lump sum and monthly contribution future value)
    total_corpus = round(fv_sip + fv_lump, 2)
    # Total invested amount (principal amount)
    total_invested = current_savings + (monthly_contribution * n)
    # Total interest earned
    total_interest = round(total_corpus - total_invested, 2)

    return total_corpus, total_invested, total_interest

# def future_value(pv, monthly_contrib, annual_rate, years):
#     r = annual_rate / 12 / 100
#     n = years * 12
#     fv = pv * (1 + r)**n + monthly_contrib * (((1 + r)**n - 1) / r)
#     return round(fv, 2)
# current_age = int(input("Enter your current age: "))
# retirement_age = int(input("Enter your desired retirement age: "))
# current_savings = float(input("Enter your current savings (₹): "))
# monthly_savings = float(input("Enter your monthly savings (₹): "))
# expected_return = float(input("Expected annual return rate before retirement (%): "))
# years_to_retirement = retirement_age - current_age
# retirement_fund = future_value(current_savings, monthly_savings, expected_return, years_to_retirement)
# print(f"\nEstimated retirement fund at age {retirement_age}: ₹{retirement_fund}")
#
#
# #  --------------------------------------------------6--------------------------------

def calculate_home_loan_eligibility(monthly_income, monthly_expenses, loan_term_years, interest_rate):
    # Maximum Loan Eligibility Criteria
    eligible_emi = monthly_income * 0.50 - monthly_expenses  # 50% of income as eligibility for EMI
    loan_term_months = loan_term_years * 12
    
    # EMI formula: EMI = [P * r * (1 + r)^n] / [(1 + r)^n - 1]
    # Where P = Principal, r = interest rate per month, n = number of payments
    r = interest_rate / 12 / 100  # Monthly interest rate
    emi = eligible_emi
    
    # Calculate loan amount (Principal) using the EMI formula rearranged
    if r == 0:  # If interest rate is zero
        loan_amount = emi * loan_term_months
    else:
        loan_amount = emi * ((1 + r) ** loan_term_months - 1) / (r * (1 + r) ** loan_term_months)
    
    loan_amount = round(loan_amount, 2)  # Round to 2 decimal places
    return loan_amount
# def calculate_max_emi(monthly_income, existing_emis, foir=0.5):
#     eligible_emi = (monthly_income * foir) - existing_emis
#     return max(eligible_emi, 0)
#
#
# def calculate_loan_eligibility(eligible_emi, annual_rate, tenure_years):
#     r = annual_rate / (12 * 100)
#     n = tenure_years * 12
#     if r == 0:
#         return eligible_emi * n
#     loan_amount = (eligible_emi * ((1 + r) ** n - 1)) / (r * (1 + r) ** n)
#     return round(loan_amount, 2)
# monthly_income = float(input("Enter your net monthly income (₹): "))
# existing_emis = float(input("Enter your total existing EMIs (₹): "))
# interest_rate = float(input("Enter expected home loan interest rate (%): "))
# loan_tenure = int(input("Enter loan tenure (in years): "))
# eligible_emi = calculate_max_emi(monthly_income, existing_emis)
# loan_eligibility = calculate_loan_eligibility(eligible_emi, interest_rate, loan_tenure)
#
# print(f"\n✅ Based on your inputs, you're eligible for a home loan of approximately: ₹{loan_eligibility}")
# print(f"With an affordable EMI of around: ₹{round(eligible_emi, 2)}")
#
# #  --------------------------------------------------7 --------------------------------



def calculate_credit_card_balance(initial_balance, interest_rate, min_payment, months):
    """
    Calculates the outstanding balance of the credit card after making minimum payments
    every month with interest applied.
    
    Parameters:
    - initial_balance: The initial amount owed on the credit card
    - interest_rate: The annual interest rate (in percentage)
    - min_payment: The minimum monthly payment (in percentage or amount)
    - months: The number of months to calculate for

    Returns:
    - The outstanding balance after the given number of months
    """
    balance = initial_balance
    monthly_interest_rate = interest_rate / 12 / 100  # Convert annual rate to monthly

    for month in range(months):
        # Apply interest first
        balance += balance * monthly_interest_rate

        # Subtract the minimum payment
        balance -= min_payment
        
        # Avoid the balance going negative
        if balance < 0:
            balance = 0
            break
    
    return round(balance, 2)
# def calculate_credit_card_interest(outstanding_amount, annual_rate, days):
#     daily_rate = annual_rate / 100 / 365
#     interest = outstanding_amount * daily_rate * days
#     return round(interest, 2)
# outstanding = float(input("Enter outstanding amount on your credit card (₹): "))
# annual_interest_rate = float(input("Enter annual interest rate (% APR): "))
# days_carried = int(input("Enter number of days the balance is carried: "))
# interest = calculate_credit_card_interest(outstanding, annual_interest_rate, days_carried)
# print(f"\n💳 Estimated interest charged: ₹{interest}")
#
# #  --------------------------------------------------8 --------------------------------
def calculate_taxable_income(gross_income, deductions):
    """
    Calculates taxable income based on gross income and deductions.

    Basic assumptions:
    - Standard deduction of ₹50,000
    - Taxable income = gross income - deductions - standard deduction
    - Taxable income can't be negative
    """
    STANDARD_DEDUCTION = 50000
    taxable_income = gross_income - deductions - STANDARD_DEDUCTION
    return max(0, round(taxable_income, 2))
# def calculate_taxable_income(salary, other_income, deductions):
#     gross_income = salary + other_income
#     taxable_income = gross_income - deductions
#     return max(taxable_income, 0)
# salary = float(input("Enter your annual salary income (₹): "))
# other_income = float(input("Enter other income (interest, rent, etc.) (₹): "))
# deductions = float(input("Enter total deductions (80C, 80D, HRA, etc.) (₹): "))
# taxable_income = calculate_taxable_income(salary, other_income, deductions)
# print(f"\n💰 Your taxable income is: ₹{taxable_income}")
#
#
# #  --------------------------------------------------9 --------------------------------

# utils.py

def budget_planner(monthly_income, monthly_expenses):
    """
    Suggests saving and investing plans based on income and expenses.

    Assumptions:
    - Save 20% of surplus
    - Invest 30% of surplus
    - Remaining 50% is free to use or reallocate
    """
    surplus = monthly_income - monthly_expenses

    if surplus <= 0:
        return {
            'surplus': surplus,
            'message': "You are overspending! Consider reducing expenses.",
            'savings': 0,
            'investments': 0,
            'free_to_use': 0
        }

    savings = round(surplus * 0.2, 2)
    investments = round(surplus * 0.3, 2)
    free_to_use = round(surplus * 0.5, 2)

    return {
        'surplus': round(surplus, 2),
        'message': "Good job! Here's how you can allocate your surplus.",
        'savings': savings,
        'investments': investments,
        'free_to_use': free_to_use
    }

# def simple_budget_planner(income, fixed_expenses, variable_expenses, savings):
#     total_income = sum(income.values())
#     total_fixed = sum(fixed_expenses.values())
#     total_variable = sum(variable_expenses.values())
#     total_savings = sum(savings.values())
#
#     total_expenses = total_fixed + total_variable + total_savings
#     balance = total_income - total_expenses
#
#     print("\n--- Budget Summary ---")
#     print(f"Total Income       : ₹{total_income}")
#     print(f"Total Fixed Expenses  : ₹{total_fixed}")
#     print(f"Total Variable Expenses: ₹{total_variable}")
#     print(f"Total Savings         : ₹{total_savings}")
#     print(f"Remaining Balance     : ₹{balance}")
#
#
# # Sample Data
# income = {
#     "Salary": 60000,
#     "Freelance": 5000
# }
#
# fixed_expenses = {
#     "Rent": 15000,
#     "Utilities": 3000,
#     "Insurance": 2000
# }
#
# variable_expenses = {
#     "Groceries": 5000,
#     "Transport": 2000,
#     "Entertainment": 1500
# }
#
# savings = {
#     "SIP": 3000,
#     "Emergency Fund": 2000
# }
#
# # Run Planner
# simple_budget_planner(income, fixed_expenses, variable_expenses, savings)
#
#
# #  --------------------------------------------------10 --------------------------------
# utils.py

def calculate_net_worth(total_assets, total_liabilities):
    """
    Calculates net worth from total assets and liabilities.
    """
    net_worth = total_assets - total_liabilities
    return round(net_worth, 2)
# def calculate_net_worth(assets, liabilities):
#     total_assets = sum(assets.values())
#     total_liabilities = sum(liabilities.values())
#     net_worth = total_assets - total_liabilities
#     return round(net_worth, 2)
#
# # Sample data for assets and liabilities
# assets = {
#     "Cash": 50000,
#     "Investments": 200000,
#     "Real Estate": 300000,
#     "Car": 150000
# }
#
# liabilities = {
#     "Mortgage": 250000,
#     "Personal Loan": 50000,
#     "Credit Card Debt": 20000
# }
#
# # Calculate net worth
# net_worth = calculate_net_worth(assets, liabilities)
#
# print(f"\n--- Net Worth Summary ---")
# print(f"Total Assets      : ₹{sum(assets.values())}")
# print(f"Total Liabilities : ₹{sum(liabilities.values())}")
# print(f"Your Net Worth    : ₹{net_worth}")
