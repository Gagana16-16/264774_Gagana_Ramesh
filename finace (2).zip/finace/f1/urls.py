from django.urls import path
from . import views

urlpatterns = [

    path('emi', views.emi, name='emi'),
    path('sip', views.sip, name='sip'),
    path('fd', views.fd, name='fd'),
    path('rd', views.rd, name='rd'),
    path('er', views.estimate, name='er'),
    path('hl', views.home_loan_estimator_view, name='hl'),
    path('cc', views.credit_card_interest_view, name='cc'),
    path('tax', views.taxable, name='tax'),
    path('bud', views.simple_budget_planner_view, name='bud'),
    path('net', views.net_worth_view, name='net'),
    ]
