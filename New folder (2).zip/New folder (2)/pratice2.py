
import math
distance = int(input("enter the distance"))
angle = int(input("enter the angle"))
angles=math.radians(angle)
a=math.tan(angle)
height=a*(distance*0.3048)
print(distance*0.3048)
print(a)
print("the height of the building",height)



