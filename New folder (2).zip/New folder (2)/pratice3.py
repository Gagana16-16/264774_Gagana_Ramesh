x1=int(input("enter the x1"))
x2=int(input("enter the x2"))
y1=int(input("enter the y1"))
y2=int(input("enter the y2"))
z1=int(input("enter the z1"))
z2=int(input("enter the z2"))

import math
distance1=((x1) - (x2) )**2+ ((y1) - (y2))**2
AB = math.sqrt(distance1)
distance2=((z1) - (z2) )**2+ ((y1) - (y2))**2
BC = math.sqrt(distance2)
distance3=((x1) - (x2) )**2+ ((z1) - (z2))**2
AC = math.sqrt(distance3)
count=0
maxi=max(AB,BC,AC)
if(maxi==AB):
    if(AB**2==BC**2+AC**2):
        count=1
elif(maxi==BC):
    if(BC**2==AB**2+AC**2):
        count=1
elif(maxi==AC):
    if(AC**2==AB**2+BC**2):
        count=1
else:
    print("not right angle")

if(AB==AC or AC==BC or BC==AB and count==1):
    print("isosceles triangle and right angles triangle")
elif(AB==AC or AC==BC or BC==AB):
    print("isosceles triangle")
elif(count==1):
    print("right angled triangle")
else:
    print("not an isosceles triangle and right angles triangle")

