
#add,sub,mul,div,mod,sqrt,log
import math
choice=int(input("enter the choice"))
print("1:add  2:sub 3:div  4:mod 5:sqrt 6:log")
if(choice==1):
    a=int(input("enter the number"))
    b=int(input("enter the number"))
    print("the addition of the number",a+b)
elif(choice==2):
    a=int(input("enter the number"))
    b=int(input("enter the number"))
    print("the subtraction of the number",a-b)
elif(choice==2):
    a=int(input("enter the number"))
    b=int(input("enter the number"))
    print("the subtraction of the number",a-b)
elif(choice==3):
    a=int(input("enter the number"))
    b=int(input("enter the number"))
    print("the multiplication of the number",a*b)
elif(choice==4):
    a=int(input("enter the number"))
    b=int(input("enter the number"))
    print("the modulus of the number",a%b)
elif(choice==5):
    a=int(input("enter the number"))
    print("the modulus of the number",math.sqrt(a))
elif(choice==6):
    a=int(input("enter the number"))
    print("the modulus of the number",math.log(a))