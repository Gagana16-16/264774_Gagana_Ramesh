# Task 1: Checking method existance
# --------------------------------------------------
 
# Create a metaclass called RequireToString that ensures any class using it must define a 
# __str__ method. If a class does not define __str__, raise a TypeError during class creation.

class str:
    def __str