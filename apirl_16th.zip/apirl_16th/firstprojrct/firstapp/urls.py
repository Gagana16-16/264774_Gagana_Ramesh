from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('index',views.index,name='index'),
    path('check', views.age_check, name='check'),
    path('fruits', views.fruit_list, name='fruits'),
    path('input', views.input_form, name='input'), # 127.0.0.1:8000/input
    path('result', views.result, name='result'),
    path('convert', views.converter, name='convert'),
    path('calculator', views.calculator, name='calculator'), # 127.0.0.1:8000/calculator
    path('calc', views.calc, name='calc'),
     path('date', views.date_time, name='date'), # 127.0.0.1:8000/calc
]