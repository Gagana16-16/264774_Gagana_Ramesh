from setuptools import setup

setup(
    name='mpg',
    version='0.1',
    description='Testing installation of Package',
    url='#',
    author='purushotham',
    author_email='purushotham@mindfullearning.in',
    license='MIT',
    packages=['mpg'],
    zip_safe=False
)