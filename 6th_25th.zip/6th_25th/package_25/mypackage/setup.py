from setuptools import setup

setup(
    name='subpackagee',
    version='0.1',
    description='Testing installation of Package',
    url='#',
    author='purushotham',
    author_email='purushotham@mindfullearning.in',
    license='MIT',
    packages=['subpackagee'],
    zip_safe=False
)