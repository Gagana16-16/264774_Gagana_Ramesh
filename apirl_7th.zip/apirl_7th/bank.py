# Problem Statement #2

# Create a class called BankAccount to represent a user’s bank account. 
# The class should allow the following:
# Use @property to return the current balance with a message like "Your balance is ₹5000".
# Use @classmethod to create a BankAccount from a dictionary containing account details like:
# {"name": "Alice", "balance": 10000}
# Use @staticmethod to check if a given withdrawal amount is valid, i.e., 
# it must be a positive number and less than or equal to the current balance.

class BankAccount:
    
    def __init__(self,name,balance=5000):
        self.name=name
        self.balance=balance
        
    @property
    def current_balance(self):
        return f'your balance is {self.balance}'
    @classmethod
    def from_dict(cls, account_details):
        # Create the BankAccount instance from a dictionary
        return cls(account_details["name"], account_details["balance"])
    # def dictio(cls,d):
    #     return BankAccount(d[name'],d['balance'])
    @staticmethod
    def checking(withdraw):
        if(withdraw<=BankAccount.balance):
            print("eligibale")
        else:
            print(" NOT eligibale")
C=BankAccount
B={"name":"gagana","balance":123}
B=(BankAccount.from_dict(B))
