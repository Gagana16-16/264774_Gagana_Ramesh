#Session 1 [45]

#Problem Statement #1:

# Write a decorator called @log_function that prints the name of the 
# function being called and its arguments before executing it.


def log_function(func):
    def enhanced(arg):
        print("hiiii")
        print(f'{func(arg)}.How are you?' )
    return enhanced
@log_function

def greet(name):
    return (f"Hello, {name}!")

greet("Gagana")



# Problem Statement #2:
# --------------------------------------------------------

# Write a decorator @double_result that doubles the result returned by any function.
# Example:
# print(add(3, 4))  # Output: 14
def double_result(func):
    def enhanced(arg1,arg2):
        print(f'{(func(arg1,arg2)) * 2}')
    return enhanced
@double_result
def add(x, y):
    return x + y
add(3,4)


# Problem Statement #3:
# --------------------------------------------------------

# Write a decorator @timer that prints how long a function takes to execute.

import time
import datetime
def timer(func):
    def enhanced():
        print("--------start--------")
        start=time.time()
        func()
        end=time.time()
        print(f'{(end-start):.2f}')
    return enhanced
@timer
def slow_function():
    time.sleep(1)
    print("Done!")

slow_function() 