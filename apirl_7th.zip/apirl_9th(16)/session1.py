# Session 1 [30]
# Problem Statement
# You are designing a system to rank products based on their ratings (on a scale of 0 to 5). 
# Two products are considered equal if their ratings are equal. A product with a lower rating 
# is considered less than one with a higher rating.
# Requirements:
# Implement a class Product with the following:
#     Attributes: name (str), rating (float)
#     Define appropriate comparison methods to allow sorting and comparison based on rating.
#     such as __le__, __gt__
#     Use @total_ordering to minimize method definitions.
# You are to:
#         Implement the class with proper ordering using @total_ordering.
#         Create a list of products and sort them.
#         Demonstrate comparisons (==, <, >=, etc.) between different products.
# class Product:
#     pass
# # === SAMPLE TEST CASE ===
# if __name__ == "__main__":
#     p1 = Product("Laptop", 4.5)
#     p2 = Product("Tablet", 4.7)
#     p3 = Product("Phone", 4.5)
#     p4 = Product("Monitor", 4.2)

#     print("Sorted Products:", sorted([p1, p2, p3, p4]))
#     print("p1 == p3:", p1 == p3)
#     print("p1 < p2:", p1 < p2)
#     print("p2 >= p4:", p2 >= p4)
# # Output
# Sorted Products: [Monitor(4.2), Laptop(4.5), Phone(4.5), Tablet(4.7)]
# p1 == p3: True
# p1 < p2: True
# p2 >= p4: True

from functools import total_ordering
@total_ordering
class Product():
    def __init__(self,name,rating):
        self.name=str(name)
        self.rating=float(rating)
    def __eq__(self, other):
        if not isinstance(other, Product):
            return NotImplemented
        return self.rating == other.rating

    def __lt__(self, other):
        if not isinstance(other, Product):
            return NotImplemented 
        return self.rating < other.rating
    
    def __gt__(self, other):
        if not isinstance(other, Product):
            return NotImplemented 
        return self.rating > other.rating

    
if __name__ == "__main__":
    p1 = Product("Laptop", 4.5)
    p2 = Product("Tablet", 4.7)
    p3 = Product("Phone", 4.5)
    p4 = Product("Monitor", 4.2)



    print("Sorted Products:", sorted([p1, p2, p3, p4]))
    a=""
    b=sorted([p1, p2, p3, p4],reverse=True)
    count=1
    dict={}
    for i in range(1,len(b)):
        dict[b[0].name]=1
        if(b[i].rating==b[i-1].rating):
            dict[b[i].name]=count
        else:
            count=count+1
            dict[b[i].name]=count

        
    print(dict)
      
    print("p1 == p3:", p1 == p3)
    print("p1 < p2:", p1 < p2)
    print("p2 >= p4:", p2 >= p4)
    print(p1==p2)
    print(p1>p2)