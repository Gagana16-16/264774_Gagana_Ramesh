import json

with open('student.json', 'r') as file:
    student_dict= json.load(file)
    

    class_dict = {}

    for i in student_dict: 
        class_dict[i['regid']] = i 

    print("\n" + "-"*100)
    print("INFO -> step 2 \n", class_dict)

# Step 3
# Calculate the average

    for regid in class_dict.keys():
        sum_of_subjects = float(class_dict[regid]['phy']) + float(class_dict[regid]['chem']) + \
                        float(class_dict[regid]['math']) + float(class_dict[regid]['bio'])
        #class_dict[regid]['avg'] = sum_of_subjects / 4
        class_dict[regid]['avg'] = sum_of_subjects / 4
        #student_dict['avg']=class_dict[regid]['avg']


    print("\n" + "-"*100)
    print("INFO -> step 3 -> Class dictionary after averages updated\n", class_dict)

    # Step 4
    # Calculate the rank

    avgs = [class_dict[regid]['avg'] for regid in class_dict.keys()]
    avgs.sort(reverse=True)

    for regid in class_dict.keys():
        class_dict[regid]['rank'] = avgs.index(class_dict[regid]['avg']) + 1
        #student_dict['rank']=class_dict[regid]['rank']

    print("\n" + "-"*100)
    print("INFO -> step 4 -> Class dictionary after ranks updated\n", class_dict)

    # Step 5
    # Display the report




    with open('student_report.json', 'w') as file:
        json.dump(class_dict, file,indent=4)