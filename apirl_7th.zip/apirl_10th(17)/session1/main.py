from student_data import Student_data
from storage import Storage

def main():
    def display_students(students: list) -> None:
        if not students:
            print("No students to display.")
        else:
            for student in students:
                print(f"[{student.id}] Name: {student.name}, Age: {student.age}, Grade: {student.grade}")


    # Initialize Student manager and Storage
    manager = Student_data()
    store = Storage()

    saved_students = store.load()
    manager.load_tasks(saved_students)

    while True:
        print("\n=== Student Management System ===")
        print("1. Add new student")
        print("2. View all students")
        print("3. Search student by ID")
        print("4. Delete a student")
        print("5. Exit")

        choice = input("Choice -> ")

        if choice == '1':
            name = input("Enter name: ").strip()
            age = input('Enter age: ').strip()
            grade = input('Enter grade: ').strip()

            if name:
                student = manager.add_student(name, age, grade)
                store.save(manager.to_dict_list())
                print(f"Student added with ID: {student.id}")
            else:
                print("Name cannot be empty.")

        elif choice == '2':
            students = manager.get_all_student()
            display_students(students)

        elif choice == '3':
            sid = input("Enter the Student ID to search: ").strip()
            student = manager.search_student(sid)
            if student:
                print(f"Found: Name: {student.name}, Age: {student.age}, Grade: {student.grade}")
            else:
                print("Student ID not found.")

        elif choice == '4':
            sid = input("Enter the Student ID to delete: ").strip()
            if manager.delete_student(sid):
                store.save(manager.to_dict_list())
                print(" Student deleted.")
            else:
                print(" Student ID not found.")

        elif choice == '5':
            print("👋 Goodbye!")
            break

        else:
            print("Invalid choice. Please select 1-5.")

if __name__ == "__main__":
    main()









# from student_data import Student_data
# from storage import Storage

# def main():
#     def display_students(students: list) -> None:
#         if not students:
#             print("No students to display.")
#         else:
#             for student in students:
#                 print(f"[{student.id}] Name: {student.name}, Age: {student.age}, Grade: {student.grade}")


#     # - Add new students
#     # - View all students
#     # - Search student by ID
#     # - Delete a student
#     # - Persist data to a file
#     manager = Student_data()
#     store = Storage()

#     saved_tasks = store.load()
#     manager.load_tasks(saved_tasks)

#     while True:

#         print("TODO Application: ")
#         print("\n1. Add new students\n2. View all students\n3.Search student by ID\n4. Delete a student\n5. Exit\n")
#         choice = input("Choice -> ")

#         if choice == '1':
#             desc = input("Enter a name: ")
#             age=input('enter the age')
#             grade=input('enter the grade')
#             if desc.strip():
#                 task = manager.add_task(desc.strip(),age,grade)
#                 store.save(manager.to_dict_list())
#                 print(f"Task added with ID: {task.id}")
#             else:
#                 print("Description cannot be empty")
#         # elif choice == '2':
#             # display_tasks(manager.get_all_tasks())
#         elif choice == '3':
#             tid = input("Enter the Task ID to complete: ")
#             if manager.serach_student(tid):
#                 store.save(manager.to_dict_list())
#                 print("Task Deleted")
#             else:
#                 print("Task ID not found")
#         elif choice == '4':
#             tid = input("Enter the Task ID to delete: ")
#             if manager.delete_task(tid):
#                 store.save(manager.to_dict_list())
#                 print("Task Deleted")
#             else:
#                 print("Task ID not found")
#         elif choice == '5':
#             print("Goodbye !")
#             break
#         else:
#             print("Invalid Choice")

# if __name__ == "__main__":

#     main()

# from student_data import Student_data
# from storage import Storage

# def main():
#     def display_students(students: list) -> None:
#         if not students:
#             print("No students to display.")
#         else:
#             for student in students:
#                 print(f"[{student.id}] Name: {student.name}, Age: {student.age}, Grade: {student.grade}")

#     # Initialize Student manager and Storage
#     manager = Student_data()
#     store = Storage()

#     # Load saved students from storage
#     saved_students = store.load()
#     manager.load_tasks(saved_students)

#     while True:
#         print("\n=== Student Management System ===")
#         print("1. Add new student")
#         print("2. View all students")
#         print("3. Search student by ID")
#         print("4. Delete a student")
#         print("5. Exit")

#         choice = input("Choice -> ")

#         if choice == '1':
#             name = input("Enter name: ").strip()
#             age = input('Enter age: ').strip()
#             grade = input('Enter grade: ').strip()

#             if name:
#                 student = manager.add_student(name, age, grade)
#                 store.save(manager.to_dict_list())
#                 print(f"✅ Student added with ID: {student.id}")
#             else:
#                 print("⚠️ Name cannot be empty.")

#         elif choice == '2':
#             students = manager.get_all_student()
#             display_students(students)

#         elif choice == '3':
#             sid = input("Enter the Student ID to search: ").strip()
#             student = manager.search_student(sid)
#             if student:
#                 print(f"🔍 Found: Name: {student.name}, Age: {student.age}, Grade: {student.grade}")
#             else:
#                 print("❌ Student ID not found.")

#         elif choice == '4':
#             sid = input("Enter the Student ID to delete: ").strip()
#             if manager.delete_student(sid):
#                 store.save(manager.to_dict_list())
#                 print("🗑️ Student deleted.")
#             else:
#                 print("❌ Student ID not found.")

#         elif choice == '5':
#             print("👋 Goodbye!")
#             break

#         else:
#             print("❌ Invalid choice. Please select 1-5.")

# if __name__ == "__main__":
#     main()
