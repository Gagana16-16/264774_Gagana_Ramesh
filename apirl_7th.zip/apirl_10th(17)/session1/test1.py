# 📋 Feature List
# ------------------------

# Add student
# View all students
# Search student by ID
# Delete student
# Persist and reload data from JSON

import unittest
from student_data import Student_data

# We write all the test cases in a class
class TestCasesForCalculator(unittest.TestCase):

    def setUp(self):
        self.student = Student_data()


# Adding a student should test two conditions:
#                 Is it added with in the student list
#                 Is the list incremented by 1
    # test case 1
    def test_add(self):
        self.student.add_student("gagana",13,'A')
        count = self.student.get_all_student()
        firstdata=len(count)
        self.student.add_student("anu",13,'B')
        count1 = self.student.get_all_student()
        secounddata=len(count1)
        #                 Is it added with in the student list
        self.assertGreater(secounddata,firstdata)
        #                 Is the list incremented by 1
        self.assertEqual(firstdata+1,len(count1))


    def test_deleting(self):
        a=self.student.add_student("gagana",13,'A')
        id1=a.id
        b=self.student.add_student("ramesh",14,'A')
        self.student.delete_student(a.id)
        total=self.student.get_all_student()
        self.assertNotIn(id1,total)
        

 

    def tearDown(self):
        del self.student

if __name__ == "__main__":
    unittest.main()