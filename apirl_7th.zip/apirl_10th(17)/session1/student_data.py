from student import Student

class Student_data(object):
    def __init__(self):
        self.data = []
        # Add new student
    def add_student(self, name, age, grade):
        student = Student(name, age, grade)
        self.data.append(student)
        return student
    
        # View all students
    def get_all_student(self):
        return self.data
    # Search student by ID
    # def search_student(self, student_id):
    #     for student in self.data:
    #         if student.id == student_id:
    #             return student
    #     print(" No student found with that ID.")
    #     return None
    
 
    
        # - Search student by ID
    def search_student(self, student_id):
        for stud1 in self.data:
            if stud1.id == student_id:
                return stud1
        else:
            print("NO ID in Student Recor")

        # - Delete a student
    def delete_student(self, student_id):
        for data1 in self.data:
            if data1.id == student_id:
                self.data.remove(data1)
                return True
        return False
    

        
        # - Persist data to a file
            # load tasks
    def load_tasks(self, student_dicts):
        self.data = [Student.from_dict(td) for td in student_dicts]

    # list of tasks in dictionary format
    def to_dict_list(self):
        return [stud.to_dict() for stud in self.data] 



# from student import Student

# class Student_data(object):
#     def __init__(self):
#         self.data = []

#     # Add new student
#     def add_student(self, name, age, grade):
#         student = Student(name, age, grade)
#         self.data.append(student)
#         return student

#     # View all students
#     def get_all_student(self):
#         return self.data

#     # Search student by ID
#     def search_student(self, student_id):
#         for student in self.data:
#             if student.id == student_id:
#                 return student
#         print(" No student found with that ID.")
#         return None

#     # Delete a student by ID
#     def delete_student(self, student_id):
#         for student in self.data:
#             if student.id == student_id:
#                 self.data.remove(student)
#                 return True
#         return False

#     # Load students from a list of dictionaries
#     def load_tasks(self, student_dicts):
#         self.data = [Student.from_dict(td) for td in student_dicts]

#     # Convert students to list of dictionaries
#     def to_dict_list(self):
#         return [student.to_dict() for student in self.data]
